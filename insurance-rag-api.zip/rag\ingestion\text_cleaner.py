"""Text cleaning for PDF-extracted content (applies only to text documents)."""

from __future__ import annotations

import re
from collections import Counter

from langchain_core.documents import Document
from loguru import logger

from rag.ingestion.pdf_loader import PAGE_BREAK_TOKEN


class TextCleaner:
    """Clean extracted text in-place on `Document.page_content`."""

    _re_page_num = re.compile(r"^\s*\d+\s*$")
    _re_irdai = re.compile(r"IRDAI\s+Reg\.?\s*No\.?\s*[\d/]+", flags=re.IGNORECASE)
    _re_cin = re.compile(r"CIN\s*:\s*[A-Z0-9]+", flags=re.IGNORECASE)
    _re_many_newlines = re.compile(r"\n{3,}")
    _re_many_spaces = re.compile(r"[ \t]{2,}")
    _re_merged_words = re.compile(r"([a-z])([A-Z])")

    def clean_documents(self, text_documents: list[Document]) -> None:
        """Clean each text document in-place."""
        for doc in text_documents:
            try:
                original = doc.page_content or ""
                cleaned = self.clean_text(original)
                doc.page_content = cleaned
            except Exception:
                logger.exception(
                    "Failed cleaning text for file={file}",
                    file=doc.metadata.get("file_name", "unknown"),
                )
                raise

    def clean_text(self, raw_text: str) -> str:
        """Clean raw text and return the cleaned string."""
        if not raw_text.strip():
            return ""

        # NOTE: since pdf_loader now creates one Document per page,
        # PAGE_BREAK_TOKEN will never appear here — but we keep the
        # split/join for safety in case the token ever appears in raw text.
        pages = [p for p in raw_text.split(PAGE_BREAK_TOKEN)]
        repeat_lines = self._detect_repeated_lines(pages)

        cleaned_pages: list[str] = []
        for page in pages:
            lines = page.splitlines()
            kept: list[str] = []
            for line in lines:
                line_stripped = line.strip()
                if not line_stripped:
                    continue
                if self._re_page_num.match(line_stripped):
                    continue
                if line_stripped in repeat_lines:
                    continue
                if self._re_irdai.search(line_stripped):
                    continue
                if self._re_cin.search(line_stripped):
                    continue

                # FIX: was < 4 which dropped section headings like
                # "D.(b). Day Care Treatment" (5 words but critical boundary).
                # Changed to < 2 so only truly empty/single-char lines are dropped.
                # _is_heading_like() still protects single meaningful words.
                if len(line_stripped.split()) < 2 and not self._is_heading_like(line_stripped):
                    continue

                kept.append(line_stripped)
            cleaned_pages.append("\n".join(kept))

        text = "\n\n".join([p for p in cleaned_pages if p.strip()])
        text = self._re_many_newlines.sub("\n\n", text)
        text = self._re_many_spaces.sub(" ", text)
        text = self._re_merged_words.sub(r"\1 \2", text)
        return text.strip()

    @staticmethod
    def _is_heading_like(line: str) -> bool:
        """Return true for short section headings that should survive cleaning."""
        if re.match(r"^(\d+(\.\d+)*|[A-Z]|[IVX]+)[.)]\s+", line, flags=re.IGNORECASE):
            return True
        letters = [ch for ch in line if ch.isalpha()]
        if letters and sum(1 for ch in letters if ch.isupper()) / len(letters) > 0.6:
            return True
        title_words = {
            "ayush",
            "claims",
            "daycare",
            "day care",
            "domiciliary",
            "hospitalization",
            "prosthetics",
            "exclusions",
            "benefits",
            "coverage",
            "maternity",
            "ambulance",
            "waiting period",
            "pre-existing",
            "grace period",
            "renewal",
        }
        return any(word in line.lower() for word in title_words)

    @staticmethod
    def _detect_repeated_lines(pages: list[str]) -> set[str]:
        """
        Detect lines repeated on 3+ pages (headers/footers) and return a set of such lines.
        """
        line_counts: Counter[str] = Counter()
        for page in pages:
            unique_lines = {ln.strip() for ln in page.splitlines() if ln.strip()}
            for ln in unique_lines:
                line_counts[ln] += 1
        return {ln for ln, cnt in line_counts.items() if cnt >= 3}


__all__ = ["TextCleaner"]