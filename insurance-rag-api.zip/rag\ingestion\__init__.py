"""Ingestion modules: load PDFs, clean text, chunk, embed, and persist."""

__all__ = []

