"""FastAPI backend package for the insurance RAG app."""
