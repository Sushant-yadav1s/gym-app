"""PDF parsing: pypdf primary, pdfplumber fallback (plus table extraction)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from statistics import mean

import pdfplumber
from langchain_core.documents import Document
from loguru import logger
from pypdf import PdfReader

from rag.config import MIN_CHARS_PER_PAGE


PAGE_BREAK_TOKEN = "\f"


@dataclass(frozen=True)
class PDFLoadResult:
    """Result of loading a single PDF."""

    text_documents: list[Document]
    table_documents: list[Document]
    skipped: bool
    reason: str | None


class PDFLoader:
    """Load PDFs from disk into LangChain Documents (text + table rows)."""

    def load_folder(self, folder_path: str) -> list[Path]:
        """Return PDF paths from a folder (non-recursive)."""
        folder = Path(folder_path)
        if not folder.exists() or not folder.is_dir():
            raise FileNotFoundError(f"Folder not found: {folder_path}")
        return sorted([p for p in folder.iterdir() if p.suffix.lower() == ".pdf"])

    def load_pdf(self, file_path: str) -> PDFLoadResult:
        """Load a PDF: try pypdf, then pdfplumber if quality gate fails."""
        pdf_path = Path(file_path)
        file_name = pdf_path.name

        try:
            pages_text, total_pages = self._extract_with_pypdf(pdf_path)
            avg_chars = self._avg_chars_per_page(pages_text)
            if avg_chars < MIN_CHARS_PER_PAGE:
                logger.warning(
                    "Low text density via pypdf for {file} avg_chars_per_page={avg}. Falling back to pdfplumber.",
                    file=file_name,
                    avg=avg_chars,
                )
                return self._extract_with_pdfplumber(pdf_path)

            # FIX: one Document per page so page_number is preserved
            text_docs: list[Document] = []
            for page_idx, page_text in enumerate(pages_text, start=1):
                if not page_text.strip():
                    continue
                text_docs.append(
                    Document(
                        page_content=page_text,
                        metadata={
                            "file_name": file_name,
                            "file_path": str(pdf_path),
                            "page_number": page_idx,
                            "total_pages": total_pages,
                            "extraction_method": "pypdf",
                            "char_count": len(page_text),
                            "doc_type": "text",
                        },
                    )
                )

            return PDFLoadResult(
                text_documents=text_docs,
                table_documents=[],
                skipped=False,
                reason=None,
            )

        except Exception as e:
            logger.exception("Failed to read PDF via pypdf: {file}", file=file_name)
            try:
                return self._extract_with_pdfplumber(pdf_path, pypdf_error=str(e))
            except Exception:
                logger.exception("Failed to read PDF via pdfplumber: {file}", file=file_name)
                return PDFLoadResult(
                    text_documents=[],
                    table_documents=[],
                    skipped=True,
                    reason="unreadable_pdf",
                )

    def _extract_with_pypdf(self, pdf_path: Path) -> tuple[list[str], int]:
        """Extract page text using pypdf."""
        try:
            reader = PdfReader(str(pdf_path))
            pages_text: list[str] = []
            for page in reader.pages:
                pages_text.append((page.extract_text() or "").strip())
            return pages_text, len(reader.pages)
        except Exception:
            logger.exception("pypdf extraction failed for {file}", file=pdf_path.name)
            raise

    def _extract_with_pdfplumber(
        self, pdf_path: Path, pypdf_error: str | None = None
    ) -> PDFLoadResult:
        """Extract per-page text and table rows using pdfplumber."""
        file_name = pdf_path.name
        try:
            text_docs: list[Document] = []
            table_docs: list[Document] = []

            with pdfplumber.open(str(pdf_path)) as pdf:
                total_pages = len(pdf.pages)
                all_pages_text: list[str] = []

                for page_idx, page in enumerate(pdf.pages, start=1):
                    page_text = (page.extract_text() or "").strip()
                    all_pages_text.append(page_text)

                    # FIX: one Document per page with page_number
                    if page_text.strip():
                        meta: dict = {
                            "file_name": file_name,
                            "file_path": str(pdf_path),
                            "page_number": page_idx,
                            "total_pages": total_pages,
                            "extraction_method": "pdfplumber",
                            "char_count": len(page_text),
                            "doc_type": "text",
                        }
                        if pypdf_error:
                            meta["pypdf_error"] = pypdf_error
                        text_docs.append(Document(page_content=page_text, metadata=meta))

                    # Table rows (already had page_number — unchanged)
                    tables = page.extract_tables() or []
                    for t_idx, table in enumerate(tables):
                        if not table:
                            continue
                        headers = [
                            str(h).strip() if h is not None else ""
                            for h in table[0]
                        ]
                        for row_idx, row in enumerate(
                            table[1:] if len(table) > 1 else []
                        ):
                            row_vals = [
                                str(v).strip() if v is not None else "" for v in row
                            ]
                            parts: list[str] = []
                            for h, v in zip(headers, row_vals, strict=False):
                                if h and v:
                                    parts.append(f"{h}: {v}")
                                elif v:
                                    parts.append(v)
                            row_text = " | ".join([p for p in parts if p])
                            if not row_text.strip():
                                continue
                            table_docs.append(
                                Document(
                                    page_content=row_text,
                                    metadata={
                                        "file_name": file_name,
                                        "file_path": str(pdf_path),
                                        "page_number": page_idx,
                                        "table_index": t_idx,
                                        "row_index": row_idx,
                                        "doc_type": "table",
                                    },
                                )
                            )

            avg_chars = self._avg_chars_per_page(all_pages_text)
            if avg_chars < MIN_CHARS_PER_PAGE:
                logger.warning(
                    "Skipping PDF due to low text density via pdfplumber for {file} avg_chars_per_page={avg}",
                    file=file_name,
                    avg=avg_chars,
                )
                return PDFLoadResult(
                    text_documents=[],
                    table_documents=[],
                    skipped=True,
                    reason="low_text_density",
                )

            return PDFLoadResult(
                text_documents=text_docs,
                table_documents=table_docs,
                skipped=False,
                reason=None,
            )

        except Exception:
            logger.exception("pdfplumber extraction failed for {file}", file=file_name)
            raise

    @staticmethod
    def _avg_chars_per_page(pages_text: list[str]) -> float:
        """Average number of characters per page (0 if empty)."""
        if not pages_text:
            return 0.0
        return float(mean([len(t) for t in pages_text]))


__all__ = ["PDFLoader", "PDFLoadResult", "PAGE_BREAK_TOKEN"]