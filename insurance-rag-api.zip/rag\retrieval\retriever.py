"""Hybrid BM25 + MMR vector retrieval over category-specific Chroma collections."""

from __future__ import annotations

from dataclasses import dataclass
import math
import re

from langchain_core.documents import Document
from loguru import logger
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder

from rag.config import (
    CATEGORIES,
    HYBRID_BM25_WEIGHT,
    HYBRID_VECTOR_WEIGHT,
    MIN_SCORE,
    MMR_LAMBDA,
    RERANK_TOP_N,
    RERANKER_ENABLED,
    RERANKER_MODEL,
    TOP_K_FETCH,
    TOP_K_RETURN,
)
from rag.ingestion.vector_store import InsuranceVectorStore


@dataclass(frozen=True)
class RetrievedChunk:
    """A chunk returned by retrieval."""

    text: str
    score: float
    source_file: str
    page_number: int
    category: str
    chunk_type: str
    keywords: list[str]
    chunk_strategy: str


class InsuranceRetriever:
    """Hybrid BM25 + MMR vector retrieval with category routing and post-filtering."""

    def __init__(self, vector_store: InsuranceVectorStore) -> None:
        self._vs = vector_store
        self._reranker: CrossEncoder | None = None
        self._bm25_cache: dict[str, tuple[list[Document], BM25Okapi]] = {}

    def retrieve(self, query: str, category: str | None = None) -> list[RetrievedChunk]:
        """
        Retrieve chunks for a query.

        - If `category` provided, search only that collection.
        - If not, search all collections, merge and re-rank by hybrid score.
        """
        if category:
            results = self._retrieve_for_category(query=query, category=category, limit=TOP_K_FETCH)
            return self._post_filter(self._rerank(query=query, chunks=results)[:TOP_K_RETURN])

        merged: list[RetrievedChunk] = []
        for cat in CATEGORIES:
            merged.extend(self._retrieve_for_category(query=query, category=cat, limit=TOP_K_FETCH))

        merged.sort(key=lambda x: x.score, reverse=True)
        merged = self._rerank(query=query, chunks=merged[:RERANK_TOP_N])[:TOP_K_RETURN]
        return self._post_filter(merged)

    def invalidate_bm25_cache(self) -> None:
        """Clear BM25 index cache — call this after reset or ingest."""
        self._bm25_cache.clear()
        logger.info("BM25 cache invalidated")

    def _retrieve_for_category(self, query: str, category: str, limit: int) -> list[RetrievedChunk]:
        """Blend MMR vector and BM25 candidates for one category."""
        vector_scores = self._vector_scores(query=query, category=category)
        bm25_scores = self._bm25_scores(query=query, category=category)
        all_docs = self._documents_by_chunk_id(category)

        merged_ids = set(vector_scores) | set(bm25_scores)
        ranked: list[RetrievedChunk] = []
        for chunk_id in merged_ids:
            doc = all_docs.get(chunk_id)
            if doc is None:
                continue
            score = (
                HYBRID_VECTOR_WEIGHT * vector_scores.get(chunk_id, 0.0)
                + HYBRID_BM25_WEIGHT * bm25_scores.get(chunk_id, 0.0)
            )
            ranked.append(self._to_retrieved_chunk(doc=doc, category=category, score=score))

        ranked.sort(key=lambda x: x.score, reverse=True)
        return ranked[:limit]

    def _rerank(self, query: str, chunks: list[RetrievedChunk]) -> list[RetrievedChunk]:
        """Use a cross-encoder reranker to reorder hybrid candidates."""
        if not RERANKER_ENABLED or not chunks:
            return chunks

        reranker = self._get_reranker()
        if reranker is None:
            return chunks

        try:
            pairs = [(query, c.text) for c in chunks]
            raw_scores = reranker.predict(pairs)
        except Exception:
            logger.exception("Reranker failed; falling back to hybrid scores")
            return chunks

        reranked: list[RetrievedChunk] = []
        for chunk, raw_score in zip(chunks, raw_scores):
            score = self._sigmoid(float(raw_score))
            reranked.append(
                RetrievedChunk(
                    text=chunk.text,
                    score=score,
                    source_file=chunk.source_file,
                    page_number=chunk.page_number,
                    category=chunk.category,
                    chunk_type=chunk.chunk_type,
                    keywords=chunk.keywords,
                    chunk_strategy="hybrid_bm25_mmr_reranked",
                )
            )

        reranked.sort(key=lambda x: x.score, reverse=True)
        return reranked

    def _get_reranker(self) -> CrossEncoder | None:
        """Lazy-load the local cross-encoder reranker."""
        if self._reranker is not None:
            return self._reranker
        try:
            logger.info("Initialising reranker model={model}", model=RERANKER_MODEL)
            self._reranker = CrossEncoder(RERANKER_MODEL)
        except Exception:
            logger.exception("Failed to initialise reranker model={model}", model=RERANKER_MODEL)
            return None
        return self._reranker

    def _vector_scores(self, query: str, category: str) -> dict[str, float]:
        """Return MMR-diversified vector scores keyed by chunk id.

        FIX: replaced similarity_search_with_score (plain cosine) with
        max_marginal_relevance_search (MMR). MMR penalises chunks that are
        too similar to already-selected results, so the 3 returned chunks
        come from different sections instead of repeating the same paragraph
        from 3 different PDFs.

        MMR_LAMBDA = 0.65 means 65% relevance + 35% diversity — controlled
        from config.py so it can be tuned without touching this file.
        """
        store = self._vs.get_store(category)
        try:
            candidates = store.max_marginal_relevance_search(
                query,
                k=TOP_K_FETCH,
                fetch_k=TOP_K_FETCH * 3,   # fetch 3x more, MMR selects the diverse subset
                lambda_mult=MMR_LAMBDA,
            )
        except Exception:
            # Fallback to cosine if MMR fails (e.g. empty collection)
            logger.warning("MMR search failed for category={cat}, falling back to cosine", cat=category)
            candidates_with_score = store.similarity_search_with_score(query, k=TOP_K_FETCH)
            scores: dict[str, float] = {}
            for doc, distance in candidates_with_score:
                cid = (doc.metadata or {}).get("chunk_id")
                if cid:
                    scores[str(cid)] = 1.0 / (1.0 + max(float(distance), 0.0))
            return scores

        # MMR returns docs without scores — assign rank-based scores (1.0 down to 0.5)
        # so position 1 is strongest and position TOP_K_FETCH is weakest
        scores: dict[str, float] = {}
        total = len(candidates)
        for rank, doc in enumerate(candidates):
            cid = (doc.metadata or {}).get("chunk_id")
            if cid:
                # Linear decay: rank 0 → 1.0, rank (total-1) → 0.5
                scores[str(cid)] = 1.0 - (0.5 * rank / max(total - 1, 1))
        return scores

    def _bm25_scores(self, query: str, category: str) -> dict[str, float]:
        """Return normalized BM25 scores keyed by chunk id.

        BM25 index is cached per category. First call builds the index from
        stored documents; subsequent calls reuse it. Call
        invalidate_bm25_cache() after ingest/reset to clear stale data.
        """
        if category in self._bm25_cache:
            docs, bm25 = self._bm25_cache[category]
        else:
            docs = self._vs.get_documents(category)
            if not docs:
                return {}
            tokenized_docs = [self._tokenize(d.page_content) for d in docs]
            bm25 = BM25Okapi(tokenized_docs)
            self._bm25_cache[category] = (docs, bm25)
            logger.debug("BM25 index built for category={cat} docs={n}", cat=category, n=len(docs))

        tokenized_query = self._tokenize(query)
        if not tokenized_query:
            return {}

        raw_scores = bm25.get_scores(tokenized_query)
        max_score = float(max(raw_scores, default=0.0))
        if max_score <= 0:
            return {}

        scored: list[tuple[str, float]] = []
        for doc, raw_score in zip(docs, raw_scores):
            chunk_id = (doc.metadata or {}).get("chunk_id")
            if not chunk_id:
                continue
            scored.append((str(chunk_id), float(raw_score) / max_score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return dict(scored[:TOP_K_FETCH])

    def _documents_by_chunk_id(self, category: str) -> dict[str, Document]:
        """Load stored documents for a category, keyed by chunk id."""
        out: dict[str, Document] = {}
        for doc in self._vs.get_documents(category):
            chunk_id = (doc.metadata or {}).get("chunk_id")
            if chunk_id:
                out[str(chunk_id)] = doc
        return out

    @staticmethod
    def _to_retrieved_chunk(doc: Document, category: str, score: float) -> RetrievedChunk:
        """Convert a stored document to the public retrieval DTO."""
        meta = doc.metadata or {}
        keywords = meta.get("keywords") or []
        if isinstance(keywords, str):
            keywords = [keywords]
        return RetrievedChunk(
            text=doc.page_content,
            score=float(score),
            source_file=str(meta.get("source_file") or meta.get("file_name") or "unknown.pdf"),
            page_number=int(meta.get("page_number", -1)),
            category=str(meta.get("category", category)),
            chunk_type=str(meta.get("chunk_type", "semantic_text")),
            keywords=list(keywords),
            chunk_strategy="hybrid_bm25_mmr",
        )

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Tokenize text for BM25 keyword matching."""
        return re.findall(r"[a-z0-9]+", text.lower())

    @staticmethod
    def _sigmoid(value: float) -> float:
        """Convert cross-encoder logits to a stable 0..1 score."""
        if value >= 0:
            z = math.exp(-value)
            return 1.0 / (1.0 + z)
        z = math.exp(value)
        return z / (1.0 + z)

    @staticmethod
    def _post_filter(chunks: list[RetrievedChunk]) -> list[RetrievedChunk]:
        """Filter by minimum score threshold."""
        kept = [c for c in chunks if c.score >= MIN_SCORE]
        if not kept:
            logger.warning("No chunks passed MIN_SCORE={min_score}", min_score=MIN_SCORE)
        return kept


__all__ = ["InsuranceRetriever", "RetrievedChunk"]