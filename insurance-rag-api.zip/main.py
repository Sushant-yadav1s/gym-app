"""Repository-level CLI entry point (wraps `rag.main`)."""

from __future__ import annotations

from rag.main import main

__all__ = ["main"]


if __name__ == "__main__":
    raise SystemExit(main())

