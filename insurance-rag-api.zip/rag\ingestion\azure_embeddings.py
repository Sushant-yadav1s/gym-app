"""Azure OpenAI embeddings (used when API key and deployment are configured)."""

from __future__ import annotations

import json
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from langchain_core.embeddings import Embeddings
from loguru import logger

from api.azure_config import (
    azure_api_key,
    azure_api_version,
    azure_embeddings_deployment,
    azure_endpoint,
)


class AzureOpenAIEmbeddings(Embeddings):
    """LangChain-compatible Azure OpenAI embeddings client."""

    def __init__(self, *, batch_size: int = 16, timeout: int = 120) -> None:
        self._batch_size = max(1, batch_size)
        self._timeout = timeout
        self._deployment = azure_embeddings_deployment()
        endpoint = azure_endpoint()
        version = azure_api_version()
        self._url = (
            f"{endpoint}/openai/deployments/{self._deployment}/embeddings?api-version={version}"
        )
        logger.info(
            "Initialising Azure OpenAI embeddings deployment={deployment}",
            deployment=self._deployment,
        )

    def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        payload: dict[str, Any] = {"input": texts}
        request = Request(
            self._url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "api-key": azure_api_key(),
                "Content-Type": "application/json",
                "User-Agent": "insurance-rag-embeddings/1.0",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=self._timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(
                f"Azure embeddings request failed with status {exc.code}: {detail[:500]}"
            ) from exc
        except URLError as exc:
            raise RuntimeError(f"Azure embeddings request failed: {exc.reason}") from exc

        items = sorted(data.get("data") or [], key=lambda row: row.get("index", 0))
        return [list(row.get("embedding") or []) for row in items]

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        vectors: list[list[float]] = []
        for start in range(0, len(texts), self._batch_size):
            vectors.extend(self._embed_batch(texts[start : start + self._batch_size]))
        return vectors

    def embed_query(self, text: str) -> list[float]:
        return self._embed_batch([text])[0]


__all__ = ["AzureOpenAIEmbeddings"]
