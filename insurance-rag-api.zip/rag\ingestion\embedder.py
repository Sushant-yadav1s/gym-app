"""Embedding model singleton (Azure OpenAI when configured, else local HuggingFace)."""

from __future__ import annotations

from langchain_core.embeddings import Embeddings
from langchain_huggingface import HuggingFaceEmbeddings
from loguru import logger

from api.azure_config import azure_embeddings_configured
from rag.config import EMBED_DEVICE, EMBED_MODEL, EMBED_NORMALIZE
from rag.ingestion.azure_embeddings import AzureOpenAIEmbeddings


class EmbeddingModel:
    """Singleton embeddings provider for the whole pipeline."""

    _instance: Embeddings | None = None
    _backend: str | None = None

    @classmethod
    def get(cls) -> Embeddings:
        """Get the shared embeddings instance."""
        if cls._instance is None:
            if azure_embeddings_configured():
                cls._backend = "azure-openai"
                cls._instance = AzureOpenAIEmbeddings()
            else:
                cls._backend = "huggingface"
                logger.info(
                    "Initialising local embeddings model={model} device={device} normalize={norm} "
                    "(set AZURE_OPENAI_API_KEY to use Azure embeddings after deployment)",
                    model=EMBED_MODEL,
                    device=EMBED_DEVICE,
                    norm=EMBED_NORMALIZE,
                )
                cls._instance = HuggingFaceEmbeddings(
                    model_name=EMBED_MODEL,
                    model_kwargs={"device": EMBED_DEVICE},
                    encode_kwargs={"normalize_embeddings": EMBED_NORMALIZE},
                )
        return cls._instance

    @classmethod
    def backend_label(cls) -> str:
        if cls._backend is not None:
            return cls._backend
        if azure_embeddings_configured():
            return "azure-openai"
        return "huggingface"


__all__ = ["EmbeddingModel"]
