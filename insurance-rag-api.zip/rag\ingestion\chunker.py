"""Chunking: SemanticChunker for text, custom passthrough chunker for tables."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import datetime, timezone

from langchain_core.documents import Document
from langchain_experimental.text_splitter import SemanticChunker
from loguru import logger

from rag.config import (
    CHUNK_OVERLAP_WORDS,
    CHUNK_SIZE_WORDS,
    MAX_CHUNK_WORDS,
    MIN_CHUNK_WORDS,
    SEMANTIC_THRESHOLD,
    SEMANTIC_THRESHOLD_TYPE,
)
from rag.ingestion.embedder import EmbeddingModel
from rag.ingestion.pdf_loader import PAGE_BREAK_TOKEN


# FIX: expanded with insurance-specific terms that were missing
INSURANCE_TERMS: list[str] = [
    "premium",
    "claim",
    "policy",
    "coverage",
    "benefit",
    "term",
    "health",
    "life",
    "sum assured",
    "nominee",
    "rider",
    "cashless",
    "tpa",
    "floater",
    "exclusion",
    "waiting period",
    "maturity",
    "endowment",
    "ulip",
    "reimbursement",
    # added
    "grace period",
    "lapse",
    "revival",
    "renewal",
    "free look",
    "surrender",
    "day care",
    "domiciliary",
    "pre-existing",
    "network hospital",
    "sum insured",
    "co-payment",
    "deductible",
    "portability",
    "no claim bonus",
]

LIFE_KEYWORDS: list[str] = [
    "term plan",
    "whole life",
    "endowment",
    "sum assured",
    "nominee",
    "death benefit",
    "ulip",
    "maturity",
    "surrender value",
    "paid up",
    "free look period",
]

# FIX: expanded — most chunks were falling into "general" because
# HEALTH_KEYWORDS was too narrow and missed common health policy terms
HEALTH_KEYWORDS: list[str] = [
    "hospitalization",
    "cashless",
    "tpa",
    "floater",
    "pre-existing",
    "network hospital",
    "reimbursement",
    "daycare",
    "day care",
    "domiciliary",
    "grace period",
    "lapse",
    "revival",
    "premium payment",
    "sum insured",
    "room rent",
    "icu charges",
    "ambulance",
    "ayush",
    "co-payment",
    "deductible",
    "no claim bonus",
    "restoration",
    "portability",
]

CLAIMS_KEYWORDS: list[str] = [
    "claim",
    "settlement",
    "discharge summary",
    "investigation",
    "rejection",
    "intimation",
    "claim form",
    "surveyor",
    "documents required",
    "claim process",
    "claim procedure",
    "reimbursement claim",
    "cashless claim",
]

TOPIC_HEADING_RE = re.compile(
    r"^\s*(?:\d+(?:\.\d+)*|[A-Z]|[IVX]+)?[.)]?\s*(?:"
    r"Prosthetics|Day\s*Care(?:\s+Treatment)?|Daycare(?:\s+Treatment)?|"
    r"AYUSH(?:\s+Treatment)?|Domiciliary(?:\s+(?:Hospitali[sz]ation|Care))?|"
    r"Obesity(?:\s+Surgery)?|Bariatric(?:\s+Surgery)?|Claims?(?:\s+(?:Procedure|Process))?|"
    r"Exclusions?|Waiting\s+Period|Pre-existing(?:\s+Disease)?|Ambulance|"
    r"Organ\s+Donor|Maternity|Cataract|Dental|Grace\s+Period|Revival|"
    r"Renewal|Free\s+Look|Surrender|Co-payment|Deductible|Portability|"
    r"No\s+Claim\s+Bonus|Restoration|Room\s+Rent"
    r")\b",
    flags=re.IGNORECASE,
)
EMBEDDED_TOPIC_HEADING_RE = re.compile(
    r"(?<!^)(?=\b(?:"
    r"Prosthetics|Day\s*Care\s+Treatment|Daycare\s+Treatment|AYUSH\s+Treatment|"
    r"Domiciliary\s+(?:Hospitali[sz]ation|Care)|Obesity\s+Surgery|Bariatric\s+Surgery|"
    r"Claims?\s+(?:Procedure|Process)|Waiting\s+Period|Pre-existing\s+Disease|"
    r"Organ\s+Donor|Maternity\s+Benefit|Grace\s+Period|Free\s+Look\s+Period|"
    r"No\s+Claim\s+Bonus|Room\s+Rent\s+Limit"
    r")\b)",
    flags=re.IGNORECASE,
)


@dataclass(frozen=True)
class ChunkingResult:
    """Chunks produced for one file."""

    chunks: list[Document]
    skipped_small: int
    skipped_large: int


class InsuranceChunker:
    """Chunk text docs via SemanticChunker; pass table docs through as-is."""

    def __init__(self) -> None:
        self._embeddings = EmbeddingModel.get()
        self._chunker = SemanticChunker(
            embeddings=self._embeddings,
            breakpoint_threshold_type=SEMANTIC_THRESHOLD_TYPE,
            breakpoint_threshold_amount=SEMANTIC_THRESHOLD,
        )

    def chunk(self, text_documents: list[Document], table_documents: list[Document]) -> ChunkingResult:
        """
        Chunk text docs via SemanticChunker and tables row-wise (already chunked).
        Returns a single flat list of Document chunks with required metadata attached.
        """
        chunks: list[Document] = []
        skipped_small = 0
        skipped_large = 0

        for doc in text_documents:
            file_name = doc.metadata.get("file_name", "unknown.pdf")
            ingested_at = self._utcnow_iso()
            original_text = doc.page_content or ""
            chunk_input_text = original_text.replace(PAGE_BREAK_TOKEN, "\n")
            source_page_number = int(doc.metadata.get("page_number", -1))

            try:
                semantic_docs = self._chunker.create_documents(
                    texts=[chunk_input_text],
                    metadatas=[doc.metadata],
                )
            except Exception:
                logger.exception("SemanticChunker failed for {file}", file=file_name)
                raise

            semantic_docs = self._shape_semantic_chunks(
                semantic_docs,
                target_words=CHUNK_SIZE_WORDS,
                overlap_words=CHUNK_OVERLAP_WORDS,
                max_words=MAX_CHUNK_WORDS,
            )

            for sd in semantic_docs:
                text = (sd.page_content or "").strip()
                wc = self._word_count(text)
                if wc < MIN_CHUNK_WORDS:
                    skipped_small += 1
                    continue
                if wc > MAX_CHUNK_WORDS:
                    logger.warning(
                        "Oversized chunk remained after shaping file={file} words={words}",
                        file=file_name,
                        words=wc,
                    )
                    skipped_large += 1
                    continue

                chunk_meta = self._build_chunk_metadata(
                    source_meta=doc.metadata,
                    chunk_text=text,
                    chunk_type="semantic_text",
                    chunk_index=len(chunks),
                    ingested_at=ingested_at,
                    page_number=source_page_number,
                )
                chunks.append(Document(page_content=text, metadata=chunk_meta))

        for tdoc in table_documents:
            file_name = tdoc.metadata.get("file_name", "unknown.pdf")
            text = (tdoc.page_content or "").strip()
            if not text:
                continue
            ingested_at = self._utcnow_iso()
            chunk_meta = self._build_chunk_metadata(
                source_meta=tdoc.metadata,
                chunk_text=text,
                chunk_type="table_row",
                chunk_index=len(chunks),
                ingested_at=ingested_at,
                page_number=int(tdoc.metadata.get("page_number", -1)),
            )
            chunks.append(Document(page_content=text, metadata=chunk_meta))
            logger.debug("Table row chunked file={file} page={page}", file=file_name, page=chunk_meta["page_number"])

        return ChunkingResult(chunks=chunks, skipped_small=skipped_small, skipped_large=skipped_large)

    def _shape_semantic_chunks(
        self,
        docs: list[Document],
        target_words: int,
        overlap_words: int,
        max_words: int,
    ) -> list[Document]:
        shaped: list[Document] = []
        for d in docs:
            text = (d.page_content or "").strip()
            if not text:
                continue
            topic_docs = self._split_topic_sections(text=text, metadata=d.metadata or {})
            for td in topic_docs:
                shaped.extend(
                    self._split_by_word_window(
                        text=td.page_content,
                        metadata=td.metadata,
                        target_words=target_words,
                        overlap_words=overlap_words,
                        max_words=max_words,
                    )
                )
        return shaped

    def _split_topic_sections(self, text: str, metadata: dict) -> list[Document]:
        """Split one semantic chunk into smaller insurance-topic sections."""
        prepared = self._insert_topic_breaks(text)
        sections: list[str] = []
        buffer: list[str] = []

        for raw_line in prepared.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            if buffer and self._is_topic_heading(line):
                sections.append("\n".join(buffer).strip())
                buffer = [line]
                continue
            buffer.append(line)

        if buffer:
            sections.append("\n".join(buffer).strip())

        return [Document(page_content=s, metadata=metadata) for s in sections if s]

    @staticmethod
    def _insert_topic_breaks(text: str) -> str:
        """Add line breaks before common insurance benefit headings embedded in paragraphs."""
        lines: list[str] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue

            split_positions: list[int] = []
            seen_topics: set[str] = set()
            if TOPIC_HEADING_RE.search(line):
                seen_topics.add(" ".join(line[:40].lower().split()[:2]))
            for match in EMBEDDED_TOPIC_HEADING_RE.finditer(line):
                start = match.start()
                topic_key = " ".join(line[start : start + 40].lower().split()[:2])
                if start == 0:
                    seen_topics.add(topic_key)
                    continue
                if topic_key in seen_topics:
                    continue
                seen_topics.add(topic_key)
                split_positions.append(start)

            if not split_positions:
                lines.append(line)
                continue

            start = 0
            for pos in split_positions:
                part = line[start:pos].strip()
                if part:
                    lines.append(part)
                start = pos
            tail = line[start:].strip()
            if tail:
                lines.append(tail)
        return "\n".join(lines)

    @staticmethod
    def _is_topic_heading(line: str) -> bool:
        """Return true when a line looks like a section heading or benefit boundary."""
        if re.match(r"^(\d+(\.\d+)*|[A-Z]|[IVX]+)[.)]\s+", line, flags=re.IGNORECASE):
            return True
        if TOPIC_HEADING_RE.search(line):
            return True
        letters = [ch for ch in line if ch.isalpha()]
        return bool(letters) and len(line.split()) <= 10 and sum(ch.isupper() for ch in letters) / len(letters) > 0.6

    @staticmethod
    def _split_by_word_window(
        text: str,
        metadata: dict,
        target_words: int,
        overlap_words: int,
        max_words: int,
    ) -> list[Document]:
        """Split text into word windows with overlap when it exceeds the max size."""
        words = [w for w in text.split() if w.strip()]
        if len(words) <= max_words:
            return [Document(page_content=text, metadata=metadata)]

        step = max(target_words - overlap_words, 1)
        chunks: list[Document] = []
        start = 0
        while len(words) - start > max_words:
            end = start + target_words
            chunk_words = words[start:end]
            if chunk_words:
                chunks.append(Document(page_content=" ".join(chunk_words), metadata=metadata))
            start += step

        remaining_words = len(words) - start
        if remaining_words < target_words and chunks:
            start = max(len(words) - target_words, 0)

        chunk_words = words[start:]
        if chunk_words:
            chunks.append(Document(page_content=" ".join(chunk_words), metadata=metadata))

        return chunks

    @staticmethod
    def _utcnow_iso() -> str:
        return datetime.now(timezone.utc).replace(tzinfo=None).isoformat()

    @staticmethod
    def _word_count(text: str) -> int:
        return len([w for w in text.split() if w.strip()])

    @staticmethod
    def _extract_keywords(chunk_text: str) -> list[str]:
        """Extract top 5 insurance terms found in chunk text."""
        lower = chunk_text.lower()
        found = [t for t in INSURANCE_TERMS if t in lower]
        return found[:5] if found else ["__none__"]

    @staticmethod
    def _detect_category(chunk_text: str) -> str:
        """Auto-detect category from chunk text.

        FIX: priority order changed — claims checked first because claims
        chunks also contain health keywords like 'hospitalization', causing
        them to previously land in 'health' instead of 'claims'.
        """
        lower = chunk_text.lower()
        if any(k in lower for k in CLAIMS_KEYWORDS):
            return "claims"
        if any(k in lower for k in HEALTH_KEYWORDS):
            return "health"
        if any(k in lower for k in LIFE_KEYWORDS):
            return "life"
        return "general"

    def _build_chunk_metadata(
        self,
        source_meta: dict,
        chunk_text: str,
        chunk_type: str,
        chunk_index: int,
        ingested_at: str,
        page_number: int,
    ) -> dict:
        """Build required chunk metadata dictionary."""
        wc = self._word_count(chunk_text)
        keywords = self._extract_keywords(chunk_text)
        category = self._detect_category(chunk_text)
        chunk_id = hashlib.md5(chunk_text.encode("utf-8")).hexdigest()

        return {
            "source_file": source_meta.get("file_name", "unknown.pdf"),
            "page_number": int(page_number),
            "category": category,
            "chunk_type": chunk_type,
            "chunk_index": int(chunk_index),
            "word_count": int(wc),
            "keywords": keywords,
            "ingested_at": ingested_at,
            "chunk_id": chunk_id,
            "file_path": source_meta.get("file_path"),
            "total_pages": source_meta.get("total_pages"),
            "extraction_method": source_meta.get("extraction_method"),
            "doc_type": source_meta.get("doc_type"),
            "table_index": source_meta.get("table_index"),
            "row_index": source_meta.get("row_index"),
        }


__all__ = [
    "InsuranceChunker",
    "ChunkingResult",
    "INSURANCE_TERMS",
]