"""
Insurance RAG ingestion + retrieval pipeline.

Import submodules (e.g. ``rag.ingestion.pdf_loader``) without loading the full
Chroma / embedding stack. Use ``from rag import InsuranceRAGPipeline`` when
you need the orchestrator.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

__all__ = ["InsuranceRAGPipeline"]

if TYPE_CHECKING:
    from rag.pipeline import InsuranceRAGPipeline


def __getattr__(name: str):
    if name == "InsuranceRAGPipeline":
        from rag.pipeline import InsuranceRAGPipeline

        return InsuranceRAGPipeline
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
