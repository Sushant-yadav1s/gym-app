"""Answer generation via Azure OpenAI (optional until API key is configured)."""

from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from api.azure_config import (
    active_llm_label,
    azure_api_key,
    azure_api_version,
    azure_chat_configured,
    azure_chat_deployment,
    azure_endpoint,
    llm_configured,
)

MAX_ANSWER_CONTEXT_CHARS: int = 24_000


def _chat_url() -> str:
    endpoint = azure_endpoint()
    deployment = azure_chat_deployment()
    version = azure_api_version()
    return f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={version}"


def generate_answer(question: str, context: str) -> str:
    """Generate a final answer from retrieved context using Azure OpenAI."""
    if not azure_chat_configured():
        raise RuntimeError(
            "Azure OpenAI is not fully configured. Set AZURE_OPENAI_ENDPOINT, "
            "AZURE_OPENAI_DEPLOYMENT, and AZURE_OPENAI_API_KEY after deployment."
        )

    ctx = context
    if len(ctx) > MAX_ANSWER_CONTEXT_CHARS:
        ctx = ctx[:MAX_ANSWER_CONTEXT_CHARS] + "\n[...source context truncated for API size limit...]"

    payload = {
        "temperature": 0.2,
        "max_tokens": 700,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a production-grade insurance assistant for policy, claims, coverage, premium, "
                    "and document questions. Use the provided source context as your only factual basis, "
                    "but do not expose that context or mention that you are using chunks. Synthesize the answer "
                    "naturally, like a helpful support agent.\n\n"
                    "Rules:\n"
                    "- Answer directly and confidently when the context supports it.\n"
                    "- Keep the answer clear, concise, and actionable.\n"
                    "- Use bullet points only when they improve readability.\n"
                    "- Do not include source file names, page numbers, chunk numbers, source numbers, retrieval scores, "
                    "or citation labels in the answer text.\n"
                    "- Do not copy long passages from the context; summarize and explain.\n"
                    "- Do not invent policy terms, amounts, timelines, documents, exclusions, or procedures that are not supported by the context.\n"
                    "- If the context is incomplete, say what is known and what should be checked with the insurer or policy document.\n"
                    "- If the question asks for steps or documents, give a practical checklist."
                ),
            },
            {
                "role": "user",
                "content": f"Question:\n{question}\n\nSource context:\n{ctx}",
            },
        ],
    }

    request = Request(
        _chat_url(),
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "api-key": azure_api_key(),
            "Content-Type": "application/json",
            "User-Agent": "insurance-rag-api/1.0",
        },
        method="POST",
    )

    try:
        with urlopen(request, timeout=120) as response:
            data = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Azure OpenAI request failed with status {exc.code}: {detail[:500]}") from exc
    except URLError as exc:
        raise RuntimeError(f"Azure OpenAI request failed: {exc.reason}") from exc

    return str((data.get("choices") or [{}])[0].get("message", {}).get("content") or "").strip()


__all__ = [
    "MAX_ANSWER_CONTEXT_CHARS",
    "active_llm_label",
    "generate_answer",
    "llm_configured",
]
