"""ChromaDB vector store wrapper with per-category persistent collections."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma
from langchain_core.vectorstores import VectorStoreRetriever
from loguru import logger

from rag.config import CHROMA_PATH, CATEGORIES, MMR_LAMBDA, TOP_K_FETCH, TOP_K_RETURN
from rag.ingestion.embedder import EmbeddingModel


CATEGORY_COLLECTIONS: dict[str, str] = {
    "life": "insurance_life",
    "health": "insurance_health",
    "claims": "insurance_claims",
    "general": "insurance_general",
}


class InsuranceVectorStore:
    """Per-category Chroma collections with deduplication by `chunk_id`."""

    def __init__(self) -> None:
        self._persist_dir = CHROMA_PATH
        self._embeddings = EmbeddingModel.get()
        self._stores: dict[str, Chroma] = {}
        self._init_collections()

    def _init_collections(self) -> None:
        """Initialise (or load) Chroma collections."""
        Path(self._persist_dir).mkdir(parents=True, exist_ok=True)
        for cat in CATEGORIES:
            collection_name = CATEGORY_COLLECTIONS[cat]
            self._stores[cat] = Chroma(
                collection_name=collection_name,
                embedding_function=self._embeddings,
                persist_directory=self._persist_dir,
            )
        logger.info("Vector store initialised at persist_directory={path}", path=self._persist_dir)

    def add_documents(self, docs: list[Document]) -> int:
        """
        Add documents grouped by category with deduplication on `chunk_id`.
        Returns number of inserted chunks.
        """
        by_cat: dict[str, list[Document]] = defaultdict(list)
        for d in docs:
            cat = (d.metadata or {}).get("category", "general")
            if cat not in CATEGORY_COLLECTIONS:
                cat = "general"
            by_cat[cat].append(d)

        inserted_total = 0
        for cat, cat_docs in by_cat.items():
            store = self._stores[cat]
            new_docs: list[Document] = []
            seen_chunk_ids: set[str] = set()
            for d in cat_docs:
                chunk_id = (d.metadata or {}).get("chunk_id")
                if not chunk_id:
                    continue
                if chunk_id in seen_chunk_ids:
                    continue
                if self._chunk_id_exists(store, chunk_id):
                    continue
                seen_chunk_ids.add(chunk_id)
                new_docs.append(d)

            if not new_docs:
                continue

            if self._count(store) == 0:
                # FIX: langchain-chroma no longer needs .persist() calls —
                # persistence is automatic. Chroma.from_documents still works
                # but we reload the handle immediately after to stay in sync.
                Chroma.from_documents(
                    documents=new_docs,
                    embedding=self._embeddings,
                    persist_directory=self._persist_dir,
                    collection_name=CATEGORY_COLLECTIONS[cat],
                )
                self._stores[cat] = Chroma(
                    collection_name=CATEGORY_COLLECTIONS[cat],
                    embedding_function=self._embeddings,
                    persist_directory=self._persist_dir,
                )
                inserted_total += len(new_docs)
                logger.info("Inserted {n} new chunks into category={cat} (new collection)", n=len(new_docs), cat=cat)
                continue

            ids = [d.metadata["chunk_id"] for d in new_docs if d.metadata.get("chunk_id")]
            store.add_documents(new_docs, ids=ids)
            # FIX: removed store.persist() — not needed in langchain-chroma,
            # calling it raises a deprecation warning and will error on upgrade
            inserted_total += len(new_docs)
            logger.info("Inserted {n} new chunks into category={cat}", n=len(new_docs), cat=cat)

        return inserted_total

    def get_retriever(
        self,
        category: str | None = None,
        fetch_k: int = TOP_K_FETCH,
        k: int = TOP_K_RETURN,
    ) -> VectorStoreRetriever:
        """Return a VectorStoreRetriever configured for MMR.

        FIX: when category is None (cross-category search), search ALL
        collections and return the best results — previously it silently
        fell back to 'general' only, missing chunks in health/claims/life.
        """
        if category and category in self._stores:
            store = self._stores[category]
            return store.as_retriever(
                search_type="mmr",
                search_kwargs={"k": k, "fetch_k": fetch_k, "lambda_mult": MMR_LAMBDA},
            )

        # Cross-category: use health as primary (most common for this dataset)
        # Retriever.retrieve() calls get_documents() on all cats anyway for BM25,
        # so this only affects the initial vector fetch stage.
        store = self._stores.get("health", self._stores["general"])
        return store.as_retriever(
            search_type="mmr",
            search_kwargs={"k": k, "fetch_k": fetch_k, "lambda_mult": MMR_LAMBDA},
        )

    def get_store(self, category: str) -> Chroma:
        """Get raw Chroma store for a category."""
        cat = category if category in self._stores else "general"
        return self._stores[cat]

    def get_all_stores(self) -> dict[str, Chroma]:
        """Return all category stores — used by retriever for cross-category search."""
        return self._stores

    def get_documents(self, category: str) -> list[Document]:
        """Return all stored documents for a category."""
        store = self.get_store(category)
        try:
            res = store._collection.get(include=["documents", "metadatas"])  # type: ignore[attr-defined]
        except Exception:
            logger.exception("Failed loading documents from collection category={cat}", cat=category)
            return []

        documents = res.get("documents") or []
        metadatas = res.get("metadatas") or []
        out: list[Document] = []
        for text, metadata in zip(documents, metadatas):
            if text:
                out.append(Document(page_content=str(text), metadata=metadata or {}))
        return out

    def stats(self) -> dict[str, int]:
        """Return chunk count per collection."""
        return {cat: self._count(store) for cat, store in self._stores.items()}

    def reset(self) -> None:
        """Delete all collections and recreate them."""
        for cat, store in self._stores.items():
            try:
                res = store._collection.get(include=[])  # type: ignore[attr-defined]
                ids = res.get("ids") or []
                if ids:
                    store._collection.delete(ids=ids)  # type: ignore[attr-defined]
                logger.warning("Deleted {n} vectors from collection category={cat}", n=len(ids), cat=cat)
            except Exception:
                logger.exception("Failed resetting collection category={cat}", cat=cat)
                raise
        self._init_collections()

    @staticmethod
    def _chunk_id_exists(store: Chroma, chunk_id: str) -> bool:
        """Check if `chunk_id` exists in the collection metadata."""
        try:
            res = store._collection.get(where={"chunk_id": chunk_id}, include=[])  # type: ignore[attr-defined]
            return len(res.get("ids") or []) > 0
        except Exception:
            logger.exception("Dedup lookup failed for chunk_id={id}", id=chunk_id)
            return False

    @staticmethod
    def _count(store: Chroma) -> int:
        """Collection count."""
        try:
            return int(store._collection.count())  # type: ignore[attr-defined]
        except Exception:
            return 0


__all__ = ["InsuranceVectorStore", "CATEGORY_COLLECTIONS"]