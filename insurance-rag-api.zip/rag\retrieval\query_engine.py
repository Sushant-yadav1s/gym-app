"""Query engine: query -> top chunks -> formatted context (no LLM calls)."""

from __future__ import annotations

from dataclasses import dataclass

from rag.retrieval.retriever import InsuranceRetriever, RetrievedChunk


@dataclass(frozen=True)
class QueryResult:
    """Result of a query over the vector store."""

    formatted_context: str
    chunks: list[RetrievedChunk]
    total_found: int
    query: str
    category_searched: str


class QueryEngine:
    """Build query results and formatted context strings."""

    def __init__(self, retriever: InsuranceRetriever) -> None:
        self._retriever = retriever

    def query(self, text: str, category: str | None = None) -> QueryResult:
        """Query the vector store and return formatted context + chunk objects."""
        chunks = self._retriever.retrieve(text, category=category)
        formatted = self._format_context(chunks)
        return QueryResult(
            formatted_context=formatted,
            chunks=chunks,
            total_found=len(chunks),
            query=text,
            category_searched=category or "all",
        )

    @staticmethod
    def _format_context(chunks: list[RetrievedChunk]) -> str:
        """Format chunks as a numbered context list."""
        if not chunks:
            return ""
        lines: list[str] = []
        for i, ch in enumerate(chunks, start=1):
            keywords_list = [k for k in (ch.keywords or []) if k and k != "__none__"]
            keywords = ", ".join(keywords_list) if keywords_list else "none"
            header = (
                f"[{i}] Source: {ch.source_file} | Page: {ch.page_number}\n"
                f"    Category: {ch.category} | Type: {ch.chunk_type}\n"
                f"    Keywords: {keywords}\n"
                f"    ---\n"
            )
            lines.append(header + f"    \"{ch.text.strip()}\"\n")
        return "\n".join(lines).strip()


__all__ = ["QueryEngine", "QueryResult"]