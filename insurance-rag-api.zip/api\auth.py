"""Simple backend auth service for the demo users."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import secrets


@dataclass(frozen=True)
class DemoUser:
    emp_id: str
    email: str
    username: str
    password: str
    full_name: str
    department: str
    designation: str
    role: str = "user"


ALLOWED_USERS: tuple[DemoUser, ...] = (
    DemoUser(
        emp_id="EMP-001",
        email="aarav.sharma@insurance.local",
        username="aarav",
        password="Aarav@123",
        full_name="Aarav Sharma",
        department="Claims",
        designation="Claims Manager",
    ),
    DemoUser(
        emp_id="EMP-002",
        email="meera.patel@insurance.local",
        username="meera",
        password="Meera@123",
        full_name="Meera Patel",
        department="Policy Operations",
        designation="Policy Analyst",
    ),
    DemoUser(
        emp_id="EMP-003",
        email="rohan.verma@insurance.local",
        username="rohan",
        password="Rohan@123",
        full_name="Rohan Verma",
        department="Customer Support",
        designation="Support Lead",
    ),
)

_sessions: dict[str, dict] = {}


def authenticate_user(identifier: str, password: str) -> DemoUser | None:
    """Return a matching dummy user for username, email, or employee ID."""
    clean_identifier = identifier.strip().lower()
    clean_password = password.strip()

    for user in ALLOWED_USERS:
        if (
            clean_identifier in {user.username.lower(), user.email.lower(), user.emp_id.lower()}
            and secrets.compare_digest(user.password, clean_password)
        ):
            return user
    return None


def create_session(user: DemoUser) -> tuple[str, dict]:
    """Create an in-memory session and return token plus public user data."""
    token = secrets.token_urlsafe(32)
    session = {
        "sessionId": secrets.token_hex(16),
        "empId": user.emp_id,
        "email": user.email,
        "username": user.username,
        "fullName": user.full_name,
        "department": user.department,
        "designation": user.designation,
        "role": user.role,
        "loginTime": datetime.now(timezone.utc).isoformat(),
    }
    _sessions[token] = session
    return token, session


def get_session(token: str | None) -> dict | None:
    """Look up a session by bearer token."""
    if not token:
        return None
    return _sessions.get(token)


def clear_session(token: str | None) -> None:
    """Remove a session by bearer token."""
    if token:
        _sessions.pop(token, None)
