"""FastAPI app for auth and RAG chat endpoints."""

from __future__ import annotations

import os
from functools import lru_cache

from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

from api.auth import authenticate_user, clear_session, create_session, get_session
from api.azure_config import (
    active_llm_label,
    azure_chat_configured,
    azure_chat_settings_present,
    azure_embeddings_configured,
    llm_configured,
)
from api.llm import generate_answer
from rag.ingestion.embedder import EmbeddingModel
from rag.pipeline import InsuranceRAGPipeline


load_dotenv()

_DEFAULT_CORS = "http://localhost:5173,http://127.0.0.1:5173"
_cors_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", _DEFAULT_CORS).split(",")
    if origin.strip()
]

app = FastAPI(title="Insurance RAG API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class LoginRequest(BaseModel):
    identifier: str = Field(min_length=1)
    password: str = Field(min_length=1)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1)
    category: str | None = None


def _bearer_token(authorization: str | None = Header(default=None)) -> str | None:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        return None
    return token


def current_user(token: str | None = Depends(_bearer_token)) -> dict:
    session = get_session(token)
    if not session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired session.")
    return session


@lru_cache(maxsize=1)
def get_pipeline() -> InsuranceRAGPipeline:
    return InsuranceRAGPipeline()


@app.get("/health")
def health() -> dict:
    return {
        "success": True,
        "status": "ok",
        "azureOpenAiSettingsPresent": azure_chat_settings_present(),
        "azureOpenAiConfigured": azure_chat_configured(),
        "azureEmbeddingsConfigured": azure_embeddings_configured(),
        "llmConfigured": llm_configured(),
        "llmProvider": active_llm_label(),
        "embeddingsProvider": EmbeddingModel.backend_label(),
    }


@app.post("/auth/login")
def login(payload: LoginRequest) -> dict:
    user = authenticate_user(payload.identifier, payload.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials.")

    token, session = create_session(user)
    return {"success": True, "token": token, "user": session, "sessionId": session["sessionId"]}


@app.post("/auth/logout")
def logout(token: str | None = Depends(_bearer_token)) -> dict:
    clear_session(token)
    return {"success": True}


@app.get("/auth/me")
def me(session: dict = Depends(current_user)) -> dict:
    return {"success": True, "user": session}


@app.post("/chat/rag")
def chat(payload: ChatRequest, session: dict = Depends(current_user)) -> dict:
    question = payload.message.strip()
    if not question:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Message cannot be empty.")

    result = get_pipeline().query(question, category=payload.category)
    citations = [
        {
            "source": chunk.source_file,
            "page": chunk.page_number,
            "category": chunk.category,
            "score": round(chunk.score, 4),
            "text": chunk.text,
        }
        for chunk in result.chunks
    ]

    if not result.formatted_context:
        response = "I could not find a matching source chunk in the indexed insurance documents."
    elif llm_configured():
        try:
            response = generate_answer(question=question, context=result.formatted_context)
        except RuntimeError as exc:
            response = (
                "I found relevant document context, but Azure OpenAI answer generation failed. "
                f"Backend detail: {exc}"
            )
    else:
        response = (
            f"Found {result.total_found} relevant source chunk(s) for {session['fullName']}.\n\n"
            f"{result.formatted_context}\n\n"
            "(Azure OpenAI is not configured yet — add AZURE_OPENAI_API_KEY after deployment for "
            "generated answers.)"
        )

    return {
        "success": True,
        "response": response,
        "citations": citations,
        "categorySearched": result.category_searched,
        "retrievalMode": "vector",
        "llmProvider": active_llm_label(),
        "embeddingsProvider": EmbeddingModel.backend_label(),
    }
