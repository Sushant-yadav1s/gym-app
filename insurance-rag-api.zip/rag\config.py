"""Central configuration for the offline insurance RAG pipeline."""

EMBED_MODEL: str = "all-MiniLM-L6-v2"
EMBED_DEVICE: str = "cpu"
EMBED_NORMALIZE: bool = True

SEMANTIC_THRESHOLD_TYPE: str = "percentile"
SEMANTIC_THRESHOLD: int = 85

CHUNK_SIZE_WORDS: int = 250
CHUNK_OVERLAP_WORDS: int = 60
MIN_CHUNK_WORDS: int = 30        # FIX: was 40 — short but valid FAQ answers were being dropped
MAX_CHUNK_WORDS: int = 280
MIN_CHARS_PER_PAGE: int = 100

TOP_K_FETCH: int = 20
TOP_K_RETURN: int = 3
MMR_LAMBDA: float = 0.5
MIN_SCORE: float = 0.2           # already fixed from 0.3
HYBRID_VECTOR_WEIGHT: float = 0.65
HYBRID_BM25_WEIGHT: float = 0.35
RERANKER_ENABLED: bool = True
RERANKER_MODEL: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
RERANK_TOP_N: int = 12

CHROMA_PATH: str = "./chroma_db"
CHUNK_OUTPUT_PATH: str = "./chunk_outputs"
CATEGORIES: list[str] = ["life", "health", "claims", "general"]

LOG_LEVEL: str = "INFO"
LOG_FILE: str = "./logs/ingestion.log"

__all__ = [
    "EMBED_MODEL",
    "EMBED_DEVICE",
    "EMBED_NORMALIZE",
    "SEMANTIC_THRESHOLD_TYPE",
    "SEMANTIC_THRESHOLD",
    "CHUNK_SIZE_WORDS",
    "CHUNK_OVERLAP_WORDS",
    "MIN_CHUNK_WORDS",
    "MAX_CHUNK_WORDS",
    "MIN_CHARS_PER_PAGE",
    "TOP_K_FETCH",
    "TOP_K_RETURN",
    "MMR_LAMBDA",
    "MIN_SCORE",
    "HYBRID_VECTOR_WEIGHT",
    "HYBRID_BM25_WEIGHT",
    "RERANKER_ENABLED",
    "RERANKER_MODEL",
    "RERANK_TOP_N",
    "CHROMA_PATH",
    "CHUNK_OUTPUT_PATH",
    "CATEGORIES",
    "LOG_LEVEL",
    "LOG_FILE",
]