"""Azure OpenAI environment configuration (deploy-safe without API key)."""

from __future__ import annotations

import os


def _strip_quotes(value: str) -> str:
    raw = value.strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
        return raw[1:-1].strip()
    return raw


def azure_endpoint() -> str:
    return _strip_quotes(os.getenv("AZURE_OPENAI_ENDPOINT", "")).rstrip("/")


def azure_api_key() -> str:
    return _strip_quotes(os.getenv("AZURE_OPENAI_API_KEY", ""))


def azure_chat_deployment() -> str:
    return _strip_quotes(os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini"))


def azure_api_version() -> str:
    return _strip_quotes(os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"))


def azure_embeddings_deployment() -> str:
    return _strip_quotes(os.getenv("AZURE_EMBEDDINGS_DEPLOYMENT", "text-embedding-3-large"))


def azure_chat_settings_present() -> bool:
    """Endpoint + deployment names are set (typical at deploy time before the key exists)."""
    return bool(azure_endpoint() and azure_chat_deployment())


def azure_chat_configured() -> bool:
    """Ready for chat completions (endpoint, deployment, and API key)."""
    return azure_chat_settings_present() and bool(azure_api_key())


def azure_embeddings_configured() -> bool:
    """Ready for Azure embedding API calls."""
    return bool(azure_endpoint() and azure_embeddings_deployment() and azure_api_key())


def active_llm_label() -> str:
    return "azure-openai" if azure_chat_configured() else "retrieval-only"


# Backward-compatible names used by the API layer
llm_configured = azure_chat_configured


__all__ = [
    "active_llm_label",
    "azure_api_key",
    "azure_api_version",
    "azure_chat_configured",
    "azure_chat_deployment",
    "azure_chat_settings_present",
    "azure_embeddings_configured",
    "azure_embeddings_deployment",
    "azure_endpoint",
    "llm_configured",
]
