"""CLI entry point for the offline insurance RAG pipeline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from loguru import logger

from rag.pipeline import InsuranceRAGPipeline

DEFAULT_PDF_FOLDER = Path("data") / "pdfs"


def build_parser() -> argparse.ArgumentParser:
    """Build CLI argument parser."""
    p = argparse.ArgumentParser(prog="insurance-rag", description="Offline insurance RAG ingestion & retrieval (no LLM).")
    sub = p.add_subparsers(dest="cmd")

    ingest = sub.add_parser("ingest", help="Ingest PDFs from a folder.")
    ingest.add_argument(
        "--folder",
        default=str(DEFAULT_PDF_FOLDER),
        help=f"Folder containing PDF files (default: {DEFAULT_PDF_FOLDER}).",
    )

    query = sub.add_parser("query", help="Query the vector store (MMR retrieval).")
    query.add_argument("--text", required=True, help="User question / query.")

    sub.add_parser("stats", help="Show vector store stats.")
    sub.add_parser("reset", help="Delete all stored vectors and recreate collections.")
    sub.add_parser("shell", help="Interactive menu mode.")

    return p


def run_shell(pipe: InsuranceRAGPipeline | None = None) -> int:
    """
    Interactive terminal menu.

    Options:
      1. Ingest PDFs
      2. Enter query for retrieval
      3. Exit
    """
    logger.info("Interactive menu started.")

    def get_pipeline() -> InsuranceRAGPipeline:
        nonlocal pipe
        if pipe is None:
            pipe = InsuranceRAGPipeline()
        return pipe

    while True:
        print("\nInsurance RAG")
        print("1. Ingest")
        print("2. Enter query for retrieval")
        print("3. Exit")

        try:
            choice = input("Choose an option (1-3): ").strip()
        except (EOFError, KeyboardInterrupt):
            logger.info("Exiting interactive mode.")
            return 0

        if not choice:
            continue

        if choice == "1":
            print(f"Ingesting all PDFs from: {DEFAULT_PDF_FOLDER}")
            res = get_pipeline().ingest(str(DEFAULT_PDF_FOLDER))
            logger.info("Ingestion summary:\n{j}", j=json.dumps(res, indent=2))
            continue

        if choice == "2":
            text = input("Enter query: ").strip()
            if not text:
                logger.warning("Query cannot be empty.")
                continue

            qr = get_pipeline().query(text)
            print(f"\nTotal found: {qr.total_found} | Category searched: {qr.category_searched}")
            if qr.formatted_context:
                print(qr.formatted_context)
            else:
                print("No matching chunks found.")
            continue

        if choice == "3":
            logger.info("Bye.")
            return 0

        logger.error("Invalid option: {choice}. Please choose 1, 2, or 3.", choice=choice)


def main(argv: list[str] | None = None) -> int:
    """Run the CLI."""
    args = build_parser().parse_args(argv)

    if args.cmd is None or args.cmd == "shell":
        return run_shell()

    pipe = InsuranceRAGPipeline()

    if args.cmd == "ingest":
        res = pipe.ingest(args.folder)
        logger.info("Ingestion summary:\n{j}", j=json.dumps(res, indent=2))
        return 0

    if args.cmd == "query":
        qr = pipe.query(args.text)
        logger.info("Total found={n} category={cat}", n=qr.total_found, cat=qr.category_searched)
        if qr.formatted_context:
            logger.info("\n{ctx}", ctx=qr.formatted_context)
        return 0

    if args.cmd == "stats":
        st = pipe.stats()
        logger.info("Vector store stats:\n{j}", j=json.dumps(st, indent=2))
        return 0

    if args.cmd == "reset":
        pipe.reset()
        logger.warning("Vector store reset complete.")
        return 0

    logger.error("Unknown command: {cmd}", cmd=args.cmd)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())

