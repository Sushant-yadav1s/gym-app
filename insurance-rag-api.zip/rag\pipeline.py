"""Pipeline orchestrator for offline insurance RAG ingestion and retrieval."""

from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from langchain_core.documents import Document
from loguru import logger
from tqdm import tqdm

from rag.config import CATEGORIES, CHUNK_OUTPUT_PATH, LOG_FILE, LOG_LEVEL
from rag.ingestion.chunker import InsuranceChunker
from rag.ingestion.embedder import EmbeddingModel
from rag.ingestion.pdf_loader import PDFLoader
from rag.ingestion.text_cleaner import TextCleaner
from rag.ingestion.vector_store import InsuranceVectorStore
from rag.retrieval.query_engine import QueryEngine, QueryResult
from rag.retrieval.retriever import InsuranceRetriever


class InsuranceRAGPipeline:
    """End-to-end ingestion + retrieval pipeline (no LLM layer)."""

    def __init__(self) -> None:
        self._configure_logging()

        self.embeddings = EmbeddingModel.get()
        self.vector_store = InsuranceVectorStore()
        self._retriever = InsuranceRetriever(self.vector_store)
        self.query_engine = QueryEngine(self._retriever)

        self._pdf_loader = PDFLoader()
        self._text_cleaner = TextCleaner()
        self._chunker = InsuranceChunker()
        logger.info("Pipeline initialised")

    def ingest(self, folder_path: str) -> dict:
        """Ingest all PDFs in a folder into the per-category Chroma collections."""
        results: dict = {
            "total_files": 0,
            "success": 0,
            "skipped": 0,
            "failed": 0,
            "total_chunks": 0,
            "chunks_per_category": {c: 0 for c in CATEGORIES},
        }

        pdf_files = self._pdf_loader.load_folder(folder_path)
        results["total_files"] = len(pdf_files)

        for pdf_path in tqdm(pdf_files, desc="Ingesting PDFs"):
            try:
                load_res = self._pdf_loader.load_pdf(str(pdf_path))
                if load_res.skipped:
                    results["skipped"] += 1
                    logger.warning("Skipped PDF file={file} reason={reason}", file=pdf_path.name, reason=load_res.reason)
                    continue

                # Step 2: clean text docs only
                self._text_cleaner.clean_documents(load_res.text_documents)

                # Step 3: chunk text docs (SemanticChunker) and pass table docs through
                chunk_res = self._chunker.chunk(load_res.text_documents, load_res.table_documents)
                self._export_chunks(pdf_path=pdf_path, chunks=chunk_res.chunks)

                # Step 5: add to vector store with dedup
                inserted = self.vector_store.add_documents(chunk_res.chunks)

                results["success"] += 1
                results["total_chunks"] += inserted

                for d in chunk_res.chunks:
                    cat = (d.metadata or {}).get("category", "general")
                    if cat in results["chunks_per_category"]:
                        results["chunks_per_category"][cat] += 1

                logger.info(
                    "Ingested file={file} chunks_total={chunks} inserted={inserted} skipped_small={ss} skipped_large={sl}",
                    file=pdf_path.name,
                    chunks=len(chunk_res.chunks),
                    inserted=inserted,
                    ss=chunk_res.skipped_small,
                    sl=chunk_res.skipped_large,
                )
            except Exception as e:
                results["failed"] += 1
                logger.exception("Failed ingesting file={file} error={err}", file=pdf_path.name, err=str(e))
                continue

        return results

    def query(self, text: str, category: str | None = None) -> QueryResult:
        """Run retrieval query (no LLM call) and return formatted context + chunks."""
        return self.query_engine.query(text, category)

    def stats(self) -> dict:
        """Vector store stats (count per collection)."""
        return self.vector_store.stats()

    def reset(self) -> None:
        """Reset all vector store collections."""
        self.vector_store.reset()

    def _export_chunks(self, pdf_path: Path, chunks: list[Document]) -> None:
        """Write separated chunk documents with metadata for audit/demo review."""
        output_dir = Path(CHUNK_OUTPUT_PATH)
        output_dir.mkdir(parents=True, exist_ok=True)

        safe_stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", pdf_path.stem).strip("._") or "document"
        jsonl_path = output_dir / f"{safe_stem}.chunks.jsonl"
        markdown_path = output_dir / f"{safe_stem}.chunks.md"

        with jsonl_path.open("w", encoding="utf-8") as f:
            for idx, doc in enumerate(chunks, start=1):
                payload = {
                    "chunk_number": idx,
                    "text": doc.page_content,
                    "metadata": doc.metadata or {},
                }
                f.write(json.dumps(payload, ensure_ascii=False) + "\n")

        with markdown_path.open("w", encoding="utf-8") as f:
            f.write(f"# Chunks: {pdf_path.name}\n\n")
            f.write(f"Total chunks: {len(chunks)}\n\n")
            for idx, doc in enumerate(chunks, start=1):
                metadata = doc.metadata or {}
                f.write(f"## Chunk {idx}\n\n")
                f.write("### Metadata\n\n")
                f.write("```json\n")
                f.write(json.dumps(metadata, indent=2, ensure_ascii=False))
                f.write("\n```\n\n")
                f.write("### Text\n\n")
                f.write((doc.page_content or "").strip())
                f.write("\n\n---\n\n")

        logger.info("Exported chunks file={file} jsonl={jsonl} markdown={markdown}", file=pdf_path.name, jsonl=jsonl_path, markdown=markdown_path)

    @staticmethod
    def _configure_logging() -> None:
        """Configure loguru to console + file."""
        logger.remove()
        logger.add(sys.stderr, level=LOG_LEVEL)
        try:
            Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
            logger.add(LOG_FILE, level=LOG_LEVEL, rotation="10 MB", retention="10 days")
        except Exception:
            logger.exception("Failed to initialise file logging at {path}", path=LOG_FILE)


__all__ = ["InsuranceRAGPipeline"]
